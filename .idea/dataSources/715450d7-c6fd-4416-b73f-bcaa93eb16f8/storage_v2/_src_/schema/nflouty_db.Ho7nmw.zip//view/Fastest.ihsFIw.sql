CREATE VIEW Fastest AS
  SELECT
    `a`.`f_name`     AS `f_name`,
    `a`.`l_name`     AS `l_name`,
    `r`.`season`     AS `season`,
    `e`.`event_name` AS `event_name`,
    `e`.`time`       AS `time`
  FROM ((`nflouty_db`.`Athlete` `a`
    JOIN `nflouty_db`.`Record` `r` ON ((`r`.`ath_id` = `a`.`ath_id`))) JOIN `nflouty_db`.`Event` `e`
      ON ((`e`.`record_id` = `r`.`record_id`)))
  ORDER BY `e`.`event_name`, `e`.`time`;

